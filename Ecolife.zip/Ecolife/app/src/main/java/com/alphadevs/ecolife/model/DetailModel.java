package com.alphadevs.ecolife.model;

import com.google.gson.annotations.SerializedName;

public class DetailModel {


    @SerializedName("Time")
    public String time;

    @SerializedName("Location")
    public String location;

    @SerializedName("Image")
    public String ImageUrl;

    @SerializedName("Status")
    public String status;

    @SerializedName("Verification")
    public String verification;

    public DetailModel(String time, String location, String imageUrl ,String status,String verification) {
        this.time = time;
        this.location = location;
        ImageUrl = imageUrl;
        this.status  =status;
        this.verification = verification;
    }

    public String getTimeEpcch(){
        return this.time;
    }
}
