package com.alphadevs.ecolife.remote;

import com.alphadevs.ecolife.model.DetailModel;


import retrofit2.Call;
import retrofit2.http.Body;

import retrofit2.http.POST;


public interface FileService {

    @POST("mydetail")
    Call<DetailModel>upload(@Body DetailModel mydetail);

}
