package com.alphadevs.ecolife.view;


import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import android.provider.MediaStore;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alphadevs.ecolife.R;
import com.alphadevs.ecolife.model.DetailModel;
import com.alphadevs.ecolife.remote.FileService;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;


public class AddFragment extends Fragment {

    @BindView(R.id.add_image)
    ImageView addImage;

    @BindView(R.id.time_add)
    TextView addTime;

    @BindView(R.id.time_location)
    TextView addLocation;

    @BindView(R.id.uploadButton)
    Button uploadButton;

    private  static  final String  SERVER_ADDRESS = "http://127.0.0.1:5000/";   // check!

    private  static final int REQUEST_IMAGE = 100;

    private FusedLocationProviderClient client;

    private Bitmap imageBitmap;

    private String timeString;
    private  String locationString;

    public AddFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_add, container, false);

        ButterKnife.bind(this,view);
        setHasOptionsMenu(true);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        addImage.setOnClickListener(view1 -> {
            getImage();
        });
        requestPermission();

        uploadButton.setOnClickListener(view12 -> {
            uploadImage();
        });
    }





    private void uploadImage() {

        DetailModel mydetail  = new DetailModel(Long.toString(System.currentTimeMillis()),locationString,"","Pending","NotVerified");


            Retrofit.Builder builder = new Retrofit.Builder().baseUrl(SERVER_ADDRESS)
                    .addConverterFactory(GsonConverterFactory.create());

            Retrofit retrofit = builder.build();



        FileService fileService = retrofit.create(FileService.class);
        Call<DetailModel>  call  = fileService.upload(mydetail);

        call.enqueue(new Callback<DetailModel>() {
            @Override
            public void onResponse(Call<DetailModel> call, Response<DetailModel> response) {

                Toast.makeText(getActivity(),"Data successfully uploaded "+response.body().verification,Toast.LENGTH_SHORT).show();

            }
            @Override
            public void onFailure(Call<DetailModel> call, Throwable t) {
                Toast.makeText(getActivity(),"An error occurred",Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void getImage() {
        Intent pictureIntent = new Intent(
                MediaStore.ACTION_IMAGE_CAPTURE
        );
        PackageManager pm = getActivity().getPackageManager();
        if(pictureIntent.resolveActivity(pm) != null) {
            startActivityForResult(pictureIntent,
                    REQUEST_IMAGE);
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                    Intent data) {
        if (requestCode == REQUEST_IMAGE ) {
            if (data != null && data.getExtras() != null) {
                 imageBitmap = (Bitmap) data.getExtras().get("data");
                addImage.setImageBitmap(imageBitmap);

                // now here i am also getting the location and time

                client  =  LocationServices.getFusedLocationProviderClient(getActivity());

                if(ActivityCompat.checkSelfPermission(getActivity(), ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity() ,android.Manifest.permission.ACCESS_COARSE_LOCATION)!= PackageManager.PERMISSION_GRANTED){
                    return;
                }

                client.getLastLocation().addOnSuccessListener(getActivity(), location -> {

                    if(location!= null){
                        addLocation.setText(location.toString());

                        locationString = location.toString();
                    }
                });
                addTime.setText(Long.toString(System.currentTimeMillis()));
                timeString = Long.toString(System.currentTimeMillis());
            }
        }
    }
    private void requestPermission(){
        ActivityCompat.requestPermissions(getActivity(),new String[]{ACCESS_FINE_LOCATION},1);

    }







}
