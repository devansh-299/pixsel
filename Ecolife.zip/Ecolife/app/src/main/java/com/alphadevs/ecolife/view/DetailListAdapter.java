package com.alphadevs.ecolife.view;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.alphadevs.ecolife.R;
import com.alphadevs.ecolife.model.DetailModel;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class DetailListAdapter  extends RecyclerView.Adapter<DetailListAdapter.DetailViewHolder> {

    private ArrayList<DetailModel> detailList ;


    public DetailListAdapter(ArrayList<DetailModel> detailList){
        this.detailList = detailList;

    }

    public  void updateDetailList (List<DetailModel> myList){
        detailList.clear();
        detailList.addAll(myList);
        notifyDataSetChanged();

    }

    @NonNull
    @Override
    public DetailViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_detail,parent,false);

        return  new  DetailViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DetailViewHolder holder, int position) {

        ImageView detailImage = holder.itemView.findViewById(R.id.item_image);
        TextView detailLocation = holder.itemView.findViewById(R.id.item_location);
        TextView detailTime = holder.itemView.findViewById(R.id.item_time);
        TextView detailStatus = holder.itemView.findViewById(R.id.item_state);
        TextView detailVerification  = holder.itemView.findViewById(R.id.item_verification);

        detailLocation.setText(detailList.get(position).location);
        detailTime.setText(detailList.get(position).time);
        detailStatus.setText(detailList.get(position).status);
        detailVerification.setText(detailList.get(position).verification);

    }

    @Override
    public int getItemCount() {
        return detailList.size();
    }

    class DetailViewHolder extends RecyclerView.ViewHolder{

        public View itemView;

        public DetailViewHolder(@NonNull View itemView) {
            super(itemView);
            this.itemView = itemView;
        }
    }
}
