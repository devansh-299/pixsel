package com.alphadevs.ecolife.view;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.NavDirections;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import butterknife.BindView;
import butterknife.ButterKnife;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alphadevs.ecolife.R;
import com.alphadevs.ecolife.model.DetailModel;
import com.alphadevs.ecolife.viewmodel.ListViewModel;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;


public class ListFragment extends Fragment {



    private GoogleSignInClient mGoogleSignInClient;

    @BindView(R.id.list_username)
    TextView userName;

    @BindView(R.id.list_id)
    TextView userId;

    @BindView(R.id.list_image)
    ImageView userImage;

    @BindView(R.id.list_recycler)
    RecyclerView detailList;

    @BindView(R.id.fab)
    FloatingActionButton fab;

    private ListViewModel viewModel;
    private DetailListAdapter detailListAdapter = new DetailListAdapter(new ArrayList<>());


    public ListFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_list, container, false);

        ButterKnife.bind(this,view);
        setHasOptionsMenu(true);
        return view;

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        GoogleSignInOptions gso  = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        mGoogleSignInClient  = GoogleSignIn.getClient(getActivity(),gso);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(getActivity());
        if(account!= null){
           userName.setText(account.getDisplayName());
           userId.setText(account.getEmail());
            Glide.with(this).load(account.getPhotoUrl()).apply(RequestOptions.circleCropTransform()).into(userImage);

        }

        viewModel = ViewModelProviders.of(this).get(ListViewModel.class);
        viewModel.refresh();

        detailList.setLayoutManager(new LinearLayoutManager(getContext()));
        detailList.setAdapter(detailListAdapter);

        fab.setOnClickListener(view1 -> {
            goToDetail();
        });


        observeViewModel();
    }

    private void goToDetail() {
       // ListFragmentDirections.ActionAdd  action =  ListFragmentDirections.actionAdd();
        //Navigation.findNavController(fab).navigate(action);

         NavDirections action  = ListFragmentDirections.actionToDetail() ;

         Navigation.findNavController(fab).navigate(action);



    }

    private void observeViewModel(){

        viewModel.detail.observe(this, mylist -> {

            if(mylist != null && mylist instanceof List){
                detailList.setVisibility(View.VISIBLE);
                detailListAdapter.updateDetailList(mylist);
            }
            else {
                Toast.makeText(getActivity(),"loading error",Toast.LENGTH_SHORT).show();
            }

        });

        viewModel.detailLoadError.observe(this, aBoolean -> {
            if(aBoolean != null && aBoolean instanceof Boolean){

            }

        });
    }




}
