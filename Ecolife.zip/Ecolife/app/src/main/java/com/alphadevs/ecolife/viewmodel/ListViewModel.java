package com.alphadevs.ecolife.viewmodel;

import android.app.Application;

import com.alphadevs.ecolife.model.DetailModel;


import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

public class ListViewModel  extends AndroidViewModel {


    public MutableLiveData<List<DetailModel>> detail = new MutableLiveData<>();
    public MutableLiveData<Boolean> detailLoadError = new MutableLiveData<>();
    public MutableLiveData<Boolean> detailLoading  = new MutableLiveData<>();


    public ListViewModel(@NonNull Application application) {
        super(application);
    }

    public void refresh(){

        DetailModel detail1  = new DetailModel(Long.toString(System.currentTimeMillis()),"Bits-Pilani Goa","lite","pending","notverified");
        DetailModel detail2  = new DetailModel(Long.toString(System.currentTimeMillis()),"Bits Goa","lite","pending","notverified");
        DetailModel detail3  = new DetailModel(Long.toString(System.currentTimeMillis()),"Bits-Pilani Goa Campus","lite","pending","notverified");

        ArrayList<DetailModel> detailList = new ArrayList<>();

        detailList.add(detail1);
        detailList.add(detail2);
        detailList.add(detail3);

        detail.setValue(detailList);
        detailLoadError.setValue(false);
        detailLoading.setValue(false);


    }
}
